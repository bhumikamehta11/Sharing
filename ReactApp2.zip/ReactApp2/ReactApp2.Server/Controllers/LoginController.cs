﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace ReactApp2.Server.Controllers
{
    [ApiController]
    [Route("[controller]")]
    
    public class LoginController : ControllerBase
    {
        [Produces("application/json")]
        [HttpPost]
        public IActionResult Index(dynamic objInput)
        {
            bool Success = false;
            bool IsRedirect = false;
            string RedirectUrl = "", AccessToken="";
            string Message = "",  UserName ="";
            try
            {
                var data = JsonConvert.DeserializeObject<dynamic>(objInput.ToString());

                //string UserName = blogPost.RootElement.GetProperty("UserName").GetString();
                //string Password = blogPost.RootElement.GetProperty("Password").GetString();
                UserName = data.UserName;
                string Password = data.Password;

                if ((UserName == "admin") && (Password == "admin"))
                {
                    Success = true;
                    IsRedirect = true;
                    RedirectUrl = "Dashboard";
                    AccessToken = "123456";


                }
                else
                    Message = "Invalid username/password";
            }
            catch (Exception ex)
            {
                //log error.
            }
            
            var objResult = new
            {
                Success = Success,
                Message = Message,
                RedirectUrl = RedirectUrl,
                IsRedirect = IsRedirect,
                AccessToken = AccessToken,
                UserName = UserName

            };


            return new JsonResult(objResult);
           
        }
    }
}
