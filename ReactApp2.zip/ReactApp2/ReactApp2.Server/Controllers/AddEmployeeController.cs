﻿using Microsoft.AspNetCore.Mvc;

namespace ReactApp2.Server.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AddEmployeeController : ControllerBase
    {
        [Produces("application/json")]
        [HttpPost]
        public IActionResult Index()
        {
            bool Success = false;
            bool IsRedirect = false;
            string RedirectUrl = "";
            string Message = "";
            try
            {
            }
            catch (Exception ex)
            {
                //log error.
            }

            var objResult = new
            {
                Success = Success,
                Message = Message,
                RedirectUrl = RedirectUrl,
                IsRedirect = IsRedirect
            };


            return new JsonResult(objResult);
            // return View();
        }
    }
}
