import React from 'react';
import { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
import { useFormik } from 'formik';
import { BASE_API_URL } from './App.jsx';



const validateEmployee = empData => {
    const errors = {};

    if (!empData.Name) {
        errors.Name = 'Please Enter Employee Name';
    } else if (empData.Name.length > 20) {
        errors.Name = 'Name cannot exceed 20 characters';
    }

    if (!empData.Location) {
        errors.Location = 'Please Enter Employee Location';
    }

    if (!empData.EmailId) {
        errors.EmailId = 'Please Enter Email ID';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(empData.EmailId)) {
        errors.EmailId = 'Invalid email address';
    }

    return errors;
};

function AddEmployee() {


    const formik = useFormik({
        initialValues: {
            Id: '',
            Name: '',
            Location: '',
            Salary: '',
            EmailId: ''
        },
        validate: validateEmployee,

        onSubmit: async (values) => {
            await new Promise((r) => setTimeout(r, 500));
            //alert(JSON.stringify(values, null, 2));

            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(values)
            };
            //alert(process.env.REACT_APP_API_URL);
            // alert(import.meta.env.VITE_API_URL);

            fetch(BASE_API_URL + '/AddEmployee', requestOptions)
                .then(async response => {
                    const isJson = response.headers.get('content-type')?.includes('application/json');
                    const data = isJson && await response.json();
                    //alert('response: ' + JSON.stringify(response));
                    //  alert('response+ data: ' + JSON.stringify(data));

                    var Success = data.Success;
                    var Message = data.Message;
                    var RedirectUrl = data.RedirectUrl;
                    var IsRedirect = data.IsRedirect;

                    if (Success == true) {
                        if (IsRedirect == true)
                            location.href = RedirectUrl;
                        else
                            if (Message != "")
                                alert(Message);
                    }
                    else
                        alert(Message);




                })


                .catch(error => {
                    alert(JSON.stringify(error.toString()));
                    // this.setState({ errorMessage: error.toString() });
                    console.error('There was an error!', error);
                });
        }
    });
    return (
        <div>
            <h2>New Employee Form...</h2>

            <form onSubmit={formik.handleSubmit} autoComplete="new-password">
                <p>
                    <label htmlFor="Id">Employee ID : </label>
                    <input type="text" name="Id" id="Id" autoComplete="off" value={formik.values.Id}
                        onChange={formik.handleChange}></input>
                </p>
                <p>
                    <label htmlFor="Name">Employee Name : </label>
                    <input type="text" name="Name" id="Name" autoComplete="off" value={formik.values.Name}
                        onChange={formik.handleChange} onBlur={formik.handleBlur}></input>
                    {formik.touched.Name && formik.errors.Name ? <span style={{ color: 'red' }}>{formik.errors.Name}</span> : null}

                </p>
                <p>
                    <label htmlFor="Location">Employee Location : </label>
                    <input type="text" name="Location" id="Location" autoComplete="off" value={formik.values.Location}
                        onChange={formik.handleChange} onBlur={formik.handleBlur}></input>
                    {formik.touched.Location && formik.errors.Location ? <span style={{ color: 'red' }}>{formik.errors.Location}</span> : null}

                </p>
                <p>
                    <label htmlFor="Salary">Employee Salary : </label>
                    <input type="text" name="Salary" id="Salary" autoComplete="off" value={formik.values.Salary}
                        onChange={formik.handleChange}></input>
                </p>
                <p>
                    <label htmlFor="EmailId">Employee Email ID : </label>
                    <input type="text" name="EmailId" id="EmailId" autoComplete="off" value={formik.values.EmailId}
                        onChange={formik.handleChange} onBlur={formik.handleBlur}></input>
                    {formik.touched.EmailId && formik.errors.EmailId ? <span style={{ color: 'red' }}>{formik.errors.EmailId}</span> : null}

                    <input autoComplete="on" style={{ display: 'none' }}
                        id="fake-hidden-input-to-stop-google-address-lookup" />
                </p>
                <button type="submit">Create</button>
            </form>
        </div>
    );
}
//const root = ReactDOM.createRoot(document.getElementById("root"));
//root.render(<Login />);
export default AddEmployee