import React, { createRoot } from "react";
import { useState, useEffect, useRef } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Login from './Login.jsx';
import Dashboard from './Dashboard.jsx';
import Logout from './Logout.jsx';

import { GetUserToken } from './Helper/UserAuth.jsx';


//https://medium.com/nerd-for-tech/get-global-variables-in-react-js-490cf68f2a73
//https://clerk.com/blog/building-a-react-login-page-template
function App() {
   

    var LoggedIn = false;
    var token = GetUserToken();
    if (token != '')
        LoggedIn = true;

    //const user = JSON.parse(localStorage.getItem(BASE_APP_NAME + 'user'))
    //if (user != null) {
    //    if ((user.token != null) && (user.token != '')) { LoggedIn = true; }

    //}
    ////alert(user.token);
    //var randomQstrTemp = Math.random();
    const [isLoggedIn, setisLoggedIn] = useState(LoggedIn);
    

    
    return (
        <BrowserRouter>
            <div>

                <h2>Welcome to App Component...</h2>
                <ul>
                    {isLoggedIn == false &&
                        <li><Link to="/Login">Login</Link></li>
                    }

                    {isLoggedIn == true &&
                        <li><Link to="/Dashboard">Dashboard</Link></li>
                    }
                    {isLoggedIn == true &&
                        <li><Link to="/Logout">Logout</Link></li>
                    }
            </ul>

                <Routes>
                    
                    <Route path="/Login" element={<Login />} />
                    
                    <Route path="/Dashboard" element={<Dashboard />} />
                        <Route path="/Logout" element={<Logout />} />
                   
                </Routes>

               {/* URL: {import.meta.env.VITE_API_URL}*/}
            </div>
        </BrowserRouter>
    )
}
const root = ReactDOM.createRoot(document.getElementById("root"));
//export const BASE_URL = `${import.meta.env.VITE_BASE_URL}/api`


root.render(<App />);
export default App;

