import { BASE_APP_NAME } from './Global.jsx';


export function CheckUserLoggedIn() {
    var LoggedIn = false;
    const user = JSON.parse(localStorage.getItem(BASE_APP_NAME + 'user'))
    if (user != null) {
        if ((user.token != null) && (user.token != undefined) && (user.token != '')) { LoggedIn = true; }

    }
    if (LoggedIn == false)
        navigate('/Login');
    //else
    //    return LoggedIn;
}
export function GetUserName() {
    var username = '';
    const user = JSON.parse(localStorage.getItem(BASE_APP_NAME + 'user'))
    if (user != null) {
        if ((user.username != null) && (user.username != undefined) && (user.username != '')) { username = user.username; }

    }
    return username;
}
export function GetUserToken() {
    var token = '';
    const user = JSON.parse(localStorage.getItem(BASE_APP_NAME + 'user'))
    if (user != null) {
        if ((user.token != null) && (user.token != undefined) && (user.token != '')) { token = user.token; }

    }
    return token;
}


