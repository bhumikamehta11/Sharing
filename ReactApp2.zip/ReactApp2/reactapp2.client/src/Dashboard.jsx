
import React from 'react';
import { useState, useEffect } from "react";
import { GetUserName, CheckUserLoggedIn  } from './Helper/UserAuth.jsx';

function Dashboard() {
    CheckUserLoggedIn();
    var userName = GetUserName();
    //var userName = '';
  return (
      <p>Welcome {userName}!</p>
  );
}

export default Dashboard;