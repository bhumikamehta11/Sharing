export const BASE_API_URL = 'http://localhost:5053';
export const BASE_APP_NAME = 'TEST';