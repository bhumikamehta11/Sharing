import React from 'react';
import { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
import { useFormik } from 'formik';
import { BASE_API_URL, BASE_APP_NAME } from './Helper/Global.jsx';
//import { useNavigate } from 'react-router-dom';



const validateEmployee = empData => {
    const errors = {};

    if (!empData.UserName) {
        errors.UserName = ' Please Enter User Name';
    } 

    if (!empData.Password) {
        errors.Password = ' Please Enter Password';
    }

   

    return errors;
};

function Login() {
  
   // const navigate = useNavigate()
        const formik = useFormik({
            initialValues: {
               
                UserName: '',
                Password: '',
               
            },
            validate: validateEmployee,
           
        onSubmit: async (values) => {
            await new Promise((r) => setTimeout(r, 500));
            //alert(JSON.stringify(values, null, 2));

            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(values)
            };
       
            fetch(BASE_API_URL+ '/Login', requestOptions)
                .then(async response => {
                    const isJson = response.headers.get('content-type')?.includes('application/json');
                    const data = isJson && await response.json();
                
                    var Success = data.Success;
                    var Message = data.Message;
                    var RedirectUrl = data.RedirectUrl;
                    var IsRedirect = data.IsRedirect;
                    var AccessToken = data.AccessToken;
                    var UserName = data.UserName;
                    if (Success == true) {
                        localStorage.setItem(BASE_APP_NAME + 'user', JSON.stringify({ username: UserName, token: AccessToken }))
                       
                        

                        if (IsRedirect == true)
                            window.location.href = '/'+ RedirectUrl;
                            //navigate('/' + RedirectUrl);

                            //location.href = RedirectUrl;
                        else
                            if (Message != "")
                                alert(Message);
                    }
                    else
                        alert(Message);
                })
               

                .catch(error => {
                    alert(JSON.stringify(error.toString()));
                   // this.setState({ errorMessage: error.toString() });
                    console.error('There was an error!', error);
                });
            }
        });
    return (
        <div className="container">

           
            <div className="row justify-content-center">

                <div className="col-xl-10 col-lg-12 col-md-9">

                    <div className="card o-hidden border-0 shadow-lg my-5">
                        <div className="card-body p-0">
                            
                            <div className="row">
                                <div className="col-lg-6 d-none d-lg-block bg-login-image"></div>
                                <div className="col-lg-6">
                                    <div className="p-5">
                                        <div className="text-center">
                                            <h1 className="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                        </div>

            <form onSubmit={formik.handleSubmit} autoComplete="new-password">

                                            <div className="form-group">
                                                <label htmlFor="UserName">User Name : </label>
                                                <input type="text" name="UserName" id="UserName" autoFocus className="form-control form-control-user" autoComplete="off" value={formik.values.UserName}
                                                    onChange={formik.handleChange} onBlur={formik.handleBlur}></input>
                                                {formik.touched.UserName && formik.errors.UserName ? <span style={{ color: 'red' }}>{formik.errors.UserName}</span> : null}
                                            </div>

              
                                            <div className="form-group">
                    <label htmlFor="Password">Password : </label>
                                                <input type="password" name="Password" id="Password" className="form-control form-control-user" autoComplete="off" value={formik.values.Password}
                        onChange={formik.handleChange} onBlur={formik.handleBlur}></input>
                    {formik.touched.Password && formik.errors.Password ? <span style={{ color: 'red' }}>{formik.errors.Password}</span> : null}
                    <input autoComplete="on" style={{ display: 'none' }}
                        id="fake-hidden-input-to-stop-google-address-lookup" />
                                            </div>
              
                                            <div className="form-group">
                                                <div className="custom-control custom-checkbox small">
                                                    <input type="checkbox" className="custom-control-input" id="customCheck" />
                                                    <label className="custom-control-label" htmlFor="customCheck">Remember
                                                            Me</label>
                                                </div>
                                            </div>
                                            <div>
                                                <button type="submit" className="btn btn-primary btn-user btn-block">Login</button>
                                            </div>
                                        </form>
                                            <hr />
                                                <div className="text-center">
                                                    <a className="small" href="forgot-password.html">Forgot Password?</a>
                                            </div>
                                    </div>
                                </div>
                            </div></div></div>
                </div>
                            </div>

           
        </div> 
    );
}
 export default Login