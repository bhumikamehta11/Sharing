
import React from 'react';
import { useState, useEffect } from "react";

import { BASE_APP_NAME } from './Helper/Global.jsx';
//import { useNavigate } from 'react-router-dom';

function Logout() {
   // const navigate = useNavigate();
    localStorage.removeItem(BASE_APP_NAME + 'user');
    //var randomQstr = Math.random();

    window.location.href = '/Login';
    //window.location.reload();
    //useEffect(() => {
    //    navigate('/Login?b=' + randomQstr); // if we go this way then page never refresh
    //}
    //);
    

    return (
        <p>Logout...</p>
    );
}

export default Logout;