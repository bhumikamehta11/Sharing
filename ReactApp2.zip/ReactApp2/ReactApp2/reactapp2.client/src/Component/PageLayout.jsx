import React from 'react';
import Footer from './Footer.jsx';
import Topbar from './Topbar.jsx';
import Sidebar from './Sidebar.jsx';


//https://dev.to/olenadrugalya/layout-component-and-why-we-use-it-in-react-d8b
const PageLayout = ({ children }) => {
    return (
        <>
            <div id="wrapper">
                {/* <!-- Sidebar -->*/}
                <Sidebar></Sidebar>
                {/* <!-- End of Sidebar -->*/}
                {/* <!-- Content Wrapper -->*/}
                <div id="content-wrapper" className="d-flex flex-column">
                    {/*  <!-- Main Content -->*/}
                    <div id="content">

                        {/*  <!-- Topbar -->*/}
                        <Topbar></Topbar>
                        {/*  <!-- End of Topbar -->*/}
                        {/*<!-- Begin Page Content -->*/}
                        <div className="container-fluid">
                <main>{children}</main>
                        </div>
                        {/*<!-- /.container-fluid -->*/}
                    </div>
                    {/*<!-- End of Main Content -->*/}
                    {/*<!-- Footer -->*/}
                    <Footer></Footer>
                    {/*<!-- End of Footer -->*/}
                </div>
                
                {/*<!-- End of Content Wrapper -->*/}
            </div>
            {/*<!-- End of Page Wrapper -->*/}

            {/*<!-- Scroll to Top Button-->*/}
            <a className="scroll-to-top rounded" href="#page-top">
                <i className="fas fa-angle-up"></i>
            </a>

            
        </>
    )
}

export default PageLayout;
