function Footer() {
    var currYear = new Date().getFullYear();
    return (
        /*< !--Footer -- >*/
        <footer className="sticky-footer bg-white">
            <div className="container my-auto">
                <div className="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website {currYear}</span>
                </div>
            </div>
        </footer>
        /*<!--End of Footer-- >*/
    )
}
export default Footer;