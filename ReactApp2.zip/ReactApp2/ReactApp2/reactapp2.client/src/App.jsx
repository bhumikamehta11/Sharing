import React, { createRoot } from "react";
import { useState, useEffect, useRef } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Login from './Login.jsx';
import Dashboard from './Dashboard.jsx';
import Logout from './Logout.jsx';
import Home from './Home.jsx';

function App() {
   

    return (
         

        <BrowserRouter>
            
            <Routes>
                <Route exact path='/' element={<Login />} />
                    <Route path="/Login" element={<Login />} />

                    <Route path="/Dashboard" element={<Dashboard />} />
                    <Route path="/Logout" element={<Logout />} />
                </Routes>   
            </BrowserRouter>
            

    )
}


export default App;

