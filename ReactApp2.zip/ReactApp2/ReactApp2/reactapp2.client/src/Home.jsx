
import React from 'react';
import { GetUserToken } from './Helper/UserAuth.jsx'

function Home() {
    var token = GetUserToken();
    if (token == '')
        window.location.href = '/Login';
    else
        window.location.href = '/Dashboard';

    return (
        <p>Home...</p>
    );
}

export default Home;