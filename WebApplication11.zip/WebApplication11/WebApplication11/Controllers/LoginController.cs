﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication11.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [Produces("application/json")]
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public JsonResult FormSubmit([FromBody] Login_Input input)
        {
            bool Success = false;
            bool IsRedirect = false;
            string RedirectUrl = "";
            string Message = "";
            try
            {
                string userName = input.userName;
                string Password = input.Password;
                if ((userName == "admin") && (Password == "admin"))
                {
                    Success = true;
                    IsRedirect = true;
                    RedirectUrl = "Dashboard";

                }
                else
                    Message = "Invalid Username/password";
            }
            catch (Exception ex)
            {
                //log error.
            }
            return Json(new { Success = Success, Message = Message, RedirectUrl = RedirectUrl, IsRedirect = IsRedirect });
        }

            

    }
    public class Login_Input
    {
        public string userName { get; set; }
        public string Password { get; set; }
       
    }
}
