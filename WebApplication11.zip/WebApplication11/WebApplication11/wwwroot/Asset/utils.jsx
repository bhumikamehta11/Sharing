﻿
  function showInfoBox(title, message) {
        var html_content =
            "<h3>" + title + "</h3>" +
            "<p>" + message + "</p>";

        Metro.infobox.create(html_content, "",
            {
                closeButton: true
                
            });
    }
function showProgress() {

    var activity = Metro.dialog.create({
        title: "Processing...",
        content: "<div>Please wait while processing...</div>",
        closeButton: false,
        actions: [
            {
                caption: "OK",
                cls: "hide-element",
                onclick: function () {
                    //alert("You clicked Agree action");
                }
            }]
        
    });

        //var activity = Metro.dialog.open('#dlgWait');


        return activity;
    };


function hideProgress(activity) {
    Metro.dialog.close(activity);

      //  Metro.dialog.close('#dlgWait');

};

function formSubmit(data, url) {
    var activity = showProgress();
   // hideProgress(activity);

    fetch(url,
        {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json()).
        then(data => {

            var Success = data.Success;
            var Message = data.Message;
            var RedirectUrl = data.RedirectUrl;
            var IsRedirect = data.IsRedirect;
           
            if (Success == true) {
                hideProgress(activity);
                if (IsRedirect == true) {
                    location.href = RedirectUrl;
                }
                else
                    showInfoBox("Sucess", Message);
            }
            else {
                hideProgress(activity);


                showInfoBox("Error", Message);
            }
        }

        )

        .catch((error) => {

            hideProgress(activity);
            showInfoBox("System Error", error);
        });
}

