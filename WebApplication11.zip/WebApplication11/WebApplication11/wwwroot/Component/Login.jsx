﻿//Why not working
//import { Redirect } from "react-router";
//import {Redirect} from "react-router-dom";
//import { Input } from "metro4-react";
class LoginForm extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = { userName: '', Password: '' };
        this.handleuserNameChange = this.handleuserNameChange.bind(this);
        this.handlePasswordChange = this.handlePasswordChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    handleuserNameChange(e) {
        this.setState({ userName: e.target.value });
    }
    handlePasswordChange(e) {
        this.setState({ Password: e.target.value });
    }
    handleSubmit(e) {
        
       
        e.preventDefault();

        const userName = this.state.userName.trim();
        const Password = this.state.Password.trim();
        if (!Password || !userName) {
            return;
        }

      

        var data = {
            userName: userName,
            Password: Password
        };

        formSubmit(data, '/Login/FormSubmit');

       
    }
            
    
    render() {
        return (

            //<form id="LoginForm" onSubmit={this.handleSubmit} onValidateForm={this.ValidateForm }   data-role="validator" data-on-before-submit="ValidateForm1" data-on-validate-form="validateForm"  data-clear-invalid="2000">
            <form id="LoginFormA" onSubmit={e => e.preventDefault()} data-role="validator" data-on-submit="FormSubmit" action="javascript:">
                <div className="form-floating mb-3">
                           

                    {/*<label htmlFor="txtUserName">Username:</label>*/}
                <input
                        type="text" id="txtUserName" data-role="input"
                        
                            data-validate="required"
                        placeholder="Enter username"
                    value={this.state.userName}
                    onChange={this.handleuserNameChange}
                    />
                        <span className="invalid_feedback">
                            Enter username
                        </span>
                        
                </div>
                <div className="form-floating mb-4">
                   {/* <label htmlFor="txtPassword">Password:</label>*/}
                    <input type="password" data-role="input" id="txtPassword"  data-validate="required" placeholder="Enter password"
                        value={this.state.Password}
                        onChange={this.handlePasswordChange} />
                    {/*<input type="password" id="txtPassword" className="form-control"*/}
                    {/*     data-validate="required" */}
                    {/*    placeholder="Enter password"*/}
                    {/*value={this.state.Password}*/}
                    {/*    onChange={this.handlePasswordChange}  />*/}
                      
                        <span className="invalid_feedback">
                            Enter password
                        </span>
                </div>

                <div className="d-flex align-items-center justify-content-between mb-4">
                    <div className="form-check">
                        <input type="checkbox" className="form-check-input" id="chkRememberMe" />
                        <label className="form-check-label" htmlFor="chkRememberMe">Remember Me</label>
                    </div>
                    <a href="ForgotPassword">Forgot Password</a>
                </div>

                   
                <button id="BtnSubmit" type="submit" className="btn btn-primary py-3 w-100 mb-4">Login</button>
                        <button id="BtnSubmitHidden" onClick={this.handleSubmit} className="hide-element">Login</button>
                   
            </form>

               
        );
    }
}

ReactDOM.render(<LoginForm />, document.getElementById('pgcontent'));

function FormSubmit(form) {
    var submitButton = document.getElementById("BtnSubmitHidden");
    submitButton.click();
}
// data-role="input"
//onClick={this.handleSubmit}
//onSubmit= {this.handleSubmit}
//function ValidateForm3() {
//    alert("data-on-error-form");
//    //https://blog.logrocket.com/detect-click-outside-react-component-how-to/
//}


//function ValidateForm1() {
//    alert("data-on-before-submit");
   
//    return true;
//}
//function validateForm() {
//   // var e = $(this);
//    alert("data-on-validate-form");
//  ///  { handleSubmit(e); }

//    //var e = document.getElementById("LoginForm");
//    //e.preventDefault();
//    //handleSubmit(form);
//    //alert("***");


//}

//function no_submit() {
//    return false;
//}
